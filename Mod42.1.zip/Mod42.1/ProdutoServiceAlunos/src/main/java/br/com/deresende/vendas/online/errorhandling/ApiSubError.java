package br.com.deresende.vendas.online.errorhandling;

abstract class ApiSubError {
}
