package br.com.deresende.vendas.online.VendaServiceAlunos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VendaServiceAlunosApplication {

	public static void main(String[] args) {
		SpringApplication.run(VendaServiceAlunosApplication.class, args);
	}

}
