package br.com.deresende.vendas.online.ProdutoServiceAlunos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdutoServiceAlunosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdutoServiceAlunosApplication.class, args);
	}

}
